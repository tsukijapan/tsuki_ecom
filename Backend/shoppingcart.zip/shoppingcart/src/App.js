import React, { useState } from 'react';
import'./App.css';
import AddToCart from './components/AddToCart';
import CartList from './components/CartList';

const App = () => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (product, quantity) => {
    const existingItem = cartItems.find(item => item.id === product.id);
    if (existingItem) {
      setCartItems(cartItems.map(item =>
        item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
      ));
    } else {
      setCartItems([...cartItems, { ...product, quantity }]);
    }
  };

  const removeFromCart = (id) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const products = [
    { id: 1, name: 'Product 1', price: 100, image: 'image1.jpg' },
    { id: 2, name: 'Product 2', price: 200, image: 'image2.jpg' },
  ];

  return (
    <div>
      <h1>My E-commerce Site</h1>
      <div className="product-list">
        {products.map(product => (
          <AddToCart key={product.id} product={product} addToCart={addToCart} />
        ))}
      </div>
      <CartList cartItems={cartItems} removeFromCart={removeFromCart} />
    </div>
  );
};

export default App;
